import React, { useState } from 'react';
import { 
  Calculator, 
  BarChart3, 
  ShieldCheck, 
  FileText, 
  Users, 
  Briefcase,
  ChevronRight,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  TrendingUp,
  Award
} from 'lucide-react';

const partners = [
  {
    name: "Sarita",
    role: "Managing Partner",
    expertise: "Audit & Assurance",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    name: "Jenisha",
    role: "Partner",
    expertise: "Corporate Taxation",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    name: "Biraj",
    role: "Partner",
    expertise: "Financial Advisory",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    name: "Samyog",
    role: "Partner",
    expertise: "Risk Management",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400&h=400"
  },
  {
    name: "Nirmal",
    role: "Partner",
    expertise: "Accounting & Bookkeeping",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400&h=400"
  }
];

const services = [
  {
    icon: <ShieldCheck className="w-8 h-8 text-blue-600" />,
    title: "Audit & Assurance",
    description: "Comprehensive auditing services ensuring financial transparency and regulatory compliance."
  },
  {
    icon: <Calculator className="w-8 h-8 text-blue-600" />,
    title: "Tax Consulting",
    description: "Strategic tax planning and compliance services for corporations and individuals."
  },
  {
    icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
    title: "Financial Advisory",
    description: "Expert guidance on mergers, acquisitions, valuations, and corporate restructuring."
  },
  {
    icon: <Briefcase className="w-8 h-8 text-blue-600" />,
    title: "Risk Management",
    description: "Identifying and mitigating financial risks to protect your business assets."
  },
  {
    icon: <FileText className="w-8 h-8 text-blue-600" />,
    title: "Accounting Services",
    description: "End-to-end bookkeeping, payroll preparation, and financial reporting."
  },
  {
    icon: <TrendingUp className="w-8 h-8 text-blue-600" />,
    title: "Business Consulting",
    description: "Strategic insights to drive growth, optimize operations, and increase profitability."
  }
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 scroll-smooth">
      {/* Navbar */}
      <nav className="fixed w-full bg-white/95 backdrop-blur-sm shadow-sm z-50 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <Users className="w-6 h-6" />
              </div>
              <span className="font-bold text-2xl tracking-tight text-slate-900">
                PentaCore <span className="text-blue-600">Advisory</span>
              </span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Home</a>
              <a href="#services" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Services</a>
              <a href="#partners" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Our Partners</a>
              <a href="#contact" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Contact</a>
              <a href="#contact" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-full font-medium transition-colors shadow-md hover:shadow-lg">
                Free Consultation
              </a>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-600 hover:text-blue-600"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <a href="#home" className="block px-3 py-2 text-slate-600 hover:text-blue-600 font-medium" onClick={() => setIsMenuOpen(false)}>Home</a>
              <a href="#services" className="block px-3 py-2 text-slate-600 hover:text-blue-600 font-medium" onClick={() => setIsMenuOpen(false)}>Services</a>
              <a href="#partners" className="block px-3 py-2 text-slate-600 hover:text-blue-600 font-medium" onClick={() => setIsMenuOpen(false)}>Our Partners</a>
              <a href="#contact" className="block px-3 py-2 text-slate-600 hover:text-blue-600 font-medium" onClick={() => setIsMenuOpen(false)}>Contact</a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative pt-20">
        <div className="absolute inset-0 z-0 h-[600px] lg:h-[700px]">
          <img 
            src="/hero-bg.jpg" 
            alt="Office background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-slate-900/75 mix-blend-multiply"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-24 lg:pt-48 lg:pb-32">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
              Expert Financial Guidance by Five Industry Leaders
            </h1>
            <p className="text-xl text-slate-200 mb-10 leading-relaxed">
              PentaCore Advisory combines the expertise of Sarita, Jenisha, Biraj, Samyog, and Nirmal to deliver unparalleled accounting, tax, and consulting services for your business growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#contact" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all shadow-lg hover:shadow-xl text-center flex items-center justify-center">
                Get Started Today
                <ChevronRight className="w-5 h-5 ml-2" />
              </a>
              <a href="#services" className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-full font-semibold text-lg transition-all text-center">
                Explore Our Services
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats/Why Us Section */}
      <section className="py-16 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="p-4">
              <div className="text-4xl font-bold text-blue-600 mb-2">5</div>
              <div className="text-slate-600 font-medium">Expert Partners</div>
            </div>
            <div className="p-4">
              <div className="text-4xl font-bold text-blue-600 mb-2">50+</div>
              <div className="text-slate-600 font-medium">Years Combined Experience</div>
            </div>
            <div className="p-4">
              <div className="text-4xl font-bold text-blue-600 mb-2">500+</div>
              <div className="text-slate-600 font-medium">Clients Served</div>
            </div>
            <div className="p-4">
              <div className="text-4xl font-bold text-blue-600 mb-2">100%</div>
              <div className="text-slate-600 font-medium">Commitment to Excellence</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-sm font-bold text-blue-600 uppercase tracking-wider mb-2">What We Do</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Comprehensive Financial Solutions</h3>
            <p className="text-lg text-slate-600">
              We provide end-to-end accounting and consulting services tailored to the unique needs of your business.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow border border-slate-100 group">
                <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors *:group-hover:text-white">
                  {service.icon}
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h4>
                <p className="text-slate-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section id="partners" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-sm font-bold text-blue-600 uppercase tracking-wider mb-2">Our Core Strength</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Meet The Five Pillars of PentaCore</h3>
            <p className="text-lg text-slate-600">
              Our firm is led by five distinguished professionals, each bringing specialized expertise to ensure holistic financial support for your business.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-12 justify-center">
            {partners.map((partner, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6 mx-auto w-48 h-48 rounded-full overflow-hidden shadow-lg border-4 border-white group-hover:border-blue-50 transition-colors">
                  <img 
                    src={partner.image} 
                    alt={partner.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 grayscale hover:grayscale-0"
                  />
                </div>
                <h4 className="text-2xl font-bold text-slate-900 mb-1">{partner.name}</h4>
                <p className="text-blue-600 font-medium mb-2">{partner.role}</p>
                <div className="inline-block bg-slate-100 px-4 py-1.5 rounded-full text-sm text-slate-700 font-medium">
                  {partner.expertise}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to transform your financial future?</h2>
              <p className="text-slate-300 text-lg mb-10 leading-relaxed">
                Schedule a consultation with one of our partners to discuss how PentaCore Advisory can help streamline your accounting and accelerate your business growth.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-600/20 p-3 rounded-lg text-blue-400 mt-1">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-lg mb-1">Our Office</h5>
                    <p className="text-slate-400">123 Financial District, Suite 500<br/>Business Hub, NY 10004</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-600/20 p-3 rounded-lg text-blue-400 mt-1">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-lg mb-1">Contact Us</h5>
                    <p className="text-slate-400">+1 (555) 123-4567<br/>contact@pentacoreadvisory.com</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-600/20 p-3 rounded-lg text-blue-400 mt-1">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-lg mb-1">Email</h5>
                    <p className="text-slate-400">inquiries@pentacoreadvisory.com</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl p-8 lg:p-10 text-slate-900 shadow-xl">
              <h3 className="text-2xl font-bold mb-6">Request a Consultation</h3>
              <form className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                  <input type="text" className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-colors" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                  <input type="email" className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-colors" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Preferred Partner (Optional)</label>
                  <select className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-colors bg-white">
                    <option>Any Partner</option>
                    <option>Sarita - Audit & Assurance</option>
                    <option>Jenisha - Corporate Taxation</option>
                    <option>Biraj - Financial Advisory</option>
                    <option>Samyog - Risk Management</option>
                    <option>Nirmal - Accounting</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
                  <textarea rows={4} className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-colors resize-none" placeholder="How can we help you?"></textarea>
                </div>
                <button type="button" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-lg transition-colors shadow-md hover:shadow-lg">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Users className="w-6 h-6 text-blue-500" />
              <span className="font-bold text-xl tracking-tight text-white">
                PentaCore <span className="text-blue-500">Advisory</span>
              </span>
            </div>
            <div className="text-sm">
              &copy; {new Date().getFullYear()} PentaCore Financial Advisory. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}